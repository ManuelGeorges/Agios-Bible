echo "python -m cProfile test_genelex.py -f samples/text.txt -o output/text.txt"
python -m cProfile test_genelex.py -f samples/text.txt -o output/text.txt
